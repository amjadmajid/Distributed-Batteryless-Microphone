# Continuous Sensing on Intermittent Power
## Abstract
## Introduction

## Related Work and Background

## Coalesced Intermittent Sensor
. Coalesced Intermittent Sensor's Nodes
. Coalesced Intermittent Sensor's On-time
. Coalesced Intermittent Sensor's Power States

## Coalesced Intermittent Microphone---A coalesced Intermittent Sensor Instant (implementation)


## Evaluation 
. Environment related experiments 
 . Source randomness 
 . Duty cycles (reason for the randomness)
. Microphone experiments
 . Show the effect of the power states 
 . Loss of randomness on sleep mode
 . The need for enforced randomness 
 . number of catched events
  . Bursty events
  . Regular events

## Conclusion 

## Acknowledgements 

